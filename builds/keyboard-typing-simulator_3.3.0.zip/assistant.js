var assistant=function(){"use strict";function se(e){return e==null||typeof e=="function"?{main:e}:e}const ie={"support-reply":"Hi Maya, thanks for flagging this — I'm sorry about the delay. Your order left our warehouse this morning and the tracking link below is live now. As an apology we've added free express shipping to your next order. Anything else, just reply here!","product-blurb":"Meet Flowdesk — the workspace that tidies itself. Capture tasks, notes and follow-ups in one place, and let smart lists surface exactly what needs you today. Less sorting, more doing.",bio:"Product designer with eight years of experience building B2B tools. Previously led design systems at Northwind Labs. Loves whiteboards, hates lorem ipsum.",email:"Hi team, I'd like to get our project kickoff on the calendar for next week. Could you share your availability Tuesday or Wednesday afternoon? Agenda: goals, timeline, and owner assignments — 30 minutes should do it. Thanks!",commit:`fix(parser): handle two-digit years in date strings

Dates like 03/04/99 previously parsed as year 0099; they now pivot on 1970.`},oe=[{id:"support-reply",label:"Support reply",instruction:"Write a friendly customer-support reply (about 60 words) resolving a shipping-delay complaint."},{id:"product-blurb",label:"Product blurb",instruction:"Write an enthusiastic 40-word product description for a fictional productivity app."},{id:"bio",label:"Short bio",instruction:"Write a 35-word professional bio for a fictional product designer."},{id:"email",label:"Email",instruction:"Write a brief, polite work email (about 70 words) scheduling a project kickoff meeting."},{id:"commit",label:"Commit message",instruction:"Write a conventional-commits style commit message with a one-sentence body for a bug fix in a date parser."}],ae="kts-assistant",G=320,Y=e=>{var g,m;const i=e.getAttribute("aria-label")??(e.id?(g=document.querySelector(`label[for="${CSS.escape(e.id)}"]`))==null?void 0:g.textContent:"")??((m=e.closest("label"))==null?void 0:m.textContent)??"",b=e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?e.placeholder:"";return{label:i.trim().slice(0,80),placeholder:b.trim().slice(0,80)}},j=(e,i)=>`Write short, realistic plain text to type${e.label?` for a form field labeled "${e.label}"`:e.placeholder?` for a form field (placeholder "${e.placeholder}")`:""}. ${i}. Plain text only, no quotes.`;function re(e){const{shadow:i,typeIntoField:b,onOpenChange:g}=e,m=document.createElement("style");m.textContent=`
    .kts-panel {
      position: fixed;
      width: ${G}px;
      max-width: calc(100vw - 16px);
      background: #ffffff;
      color: #172033;
      border: 1px solid #d7dce3;
      border-radius: 12px;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.22);
      z-index: 2147483647;
      font: 13px/1.45 system-ui, -apple-system, sans-serif;
      display: none;
      flex-direction: column;
      gap: 8px;
      padding: 12px;
    }
    .kts-panel.kts-open { display: flex; }
    .kts-row { display: flex; align-items: center; gap: 6px; cursor: move; touch-action: none; user-select: none; }
    .kts-title { font-weight: 600; font-size: 12px; }
    .kts-drag-hint { font-size: 11px; color: #8a919c; margin-right: 2px; cursor: move; }
    .kts-sub { font-size: 10px; color: #8a919c; margin-left: auto; }
    .kts-x { margin-left: 6px; border: none; background: transparent; cursor: pointer; color: #8a919c; font-size: 15px; line-height: 1; padding: 2px 4px; border-radius: 4px; }
    .kts-x:hover { background: rgba(127,127,127,.18); }
    .kts-chips { display: flex; flex-wrap: wrap; gap: 5px; }
    /* Theme-independent: text inherits the panel colour (always readable),
       fill/border use translucent grey that reads on light and dark alike. */
    .kts-chip { border: 1px solid rgba(127,127,127,.42); background: rgba(127,127,127,.10); border-radius: 999px; padding: 3px 9px; font-size: 11px; cursor: pointer; color: inherit; }
    .kts-chip:hover { border-color: #8384dd; color: #8384dd; background: rgba(91,91,214,.14); }
    .kts-chip:disabled { opacity: .5; cursor: not-allowed; }
    @media (prefers-color-scheme: dark) {
      .kts-panel { background: #22252a; color: #f3f4f6; border-color: #3d424a; }
      .kts-panel textarea, .kts-panel .kts-preview { background: #17191d; color: #f3f4f6; border-color: #3d424a; }
    }
    .kts-panel textarea { width: 100%; box-sizing: border-box; resize: none; height: 46px; border: 1px solid #d7dce3; border-radius: 8px; padding: 7px 9px; font: inherit; }
    .kts-panel textarea:focus, .kts-preview:focus-within { outline: 2px solid #5b5bd6; outline-offset: 1px; }
    .kts-gen-row { display: flex; gap: 6px; }
    .kts-btn { border: none; border-radius: 8px; padding: 7px 12px; font: inherit; font-weight: 600; font-size: 12px; cursor: pointer; }
    .kts-btn-primary { background: #5b5bd6; color: #fff; }
    .kts-btn-primary:hover { background: #4a48c4; }
    .kts-btn-primary:disabled { background: #c9c9f0; cursor: not-allowed; }
    .kts-btn-ghost { background: transparent; border: 1px solid #d7dce3; color: inherit; }
    .kts-btn-ghost:hover { background: rgba(0,0,0,.05); }
    .kts-btn-ghost:disabled { opacity: .5; cursor: not-allowed; }
    .kts-preview { min-height: 40px; max-height: 130px; overflow-y: auto; border: 1px solid #d7dce3; border-radius: 8px; padding: 7px 9px; font-size: 12px; white-space: pre-wrap; word-break: break-word; }
    .kts-preview:empty::before { content: attr(data-placeholder); color: #9aa1ac; }
    .kts-note { font-size: 10px; color: #8a919c; }
    .kts-foot { display: flex; align-items: center; gap: 6px; }
    .kts-foot .kts-hide { margin-left: auto; font-size: 10px; color: #8a919c; background: none; border: none; cursor: pointer; }
    .kts-foot .kts-hide:hover { text-decoration: underline; }
  `,i.appendChild(m);const c=document.createElement("div");c.className="kts-panel",c.innerHTML=`
    <div class="kts-row" title="Drag to move">
      <span class="kts-drag-hint" aria-hidden="true">⠿</span>
      <span class="kts-title">TypeReel ✨</span>
      <span class="kts-sub" data-el="sub"></span>
      <button class="kts-x" data-el="close" aria-label="Close" title="Close (Esc)">✕</button>
    </div>
    <div class="kts-chips" data-el="chips"></div>
    <textarea data-el="prompt" placeholder="Describe what to write…"></textarea>
    <div class="kts-gen-row">
      <button class="kts-btn kts-btn-primary" data-el="generate" style="flex:1">Generate</button>
    </div>
    <div class="kts-preview" data-el="preview" tabindex="0" data-placeholder="Generated text appears here…"></div>
    <div class="kts-note" data-el="note">Runs on your device · nothing leaves your machine.</div>
    <div class="kts-foot">
      <button class="kts-btn kts-btn-primary" data-el="insert" style="flex:1">Insert &amp; Type</button>
      <button class="kts-btn kts-btn-ghost" data-el="regen" title="Regenerate">↻</button>
      <button class="kts-hide" data-el="hide">Hide on this page</button>
    </div>
  `,i.appendChild(c);const a=t=>c.querySelector(`[data-el="${t}"]`),o=a("sub"),x=a("chips"),k=a("prompt"),T=a("generate"),E=a("preview"),A=a("note"),D=a("insert"),W=a("regen");let n=!1,r=null,u="unavailable",d=null,w=0,y=0,p="",C=!1;const P=()=>{if(d)return d;try{return d=chrome.runtime.connect({name:ae}),d.onMessage.addListener(v),d.onDisconnect.addListener(()=>{d=null}),d}catch{return d=null,null}},M=t=>{var f;return(f=P())==null?void 0:f.postMessage(t)},I=t=>{var f;C=t,T.disabled=t||u!=="available"||!k.value.trim(),W.disabled=t||u!=="available"||!p,D.disabled=t||!((f=E.textContent)!=null&&f.trim()),T.textContent=t?"Generating…":"Generate"},O=()=>{const t=u==="available";k.style.display=t?"":"none",T.parentElement&&(T.parentElement.style.display=t?"":"none"),W.style.display=t?"":"none",A.textContent=t?"Runs on your device · nothing leaves your machine.":u==="downloadable"||u==="downloading"?"Enable on-device AI from the TypeReel popup. Chips insert samples meanwhile.":"On-device AI needs Chrome 138+ on a supported desktop. Chips insert samples.",I(!1),B()},z=t=>{x.replaceChildren();for(const f of t){const h=document.createElement("button");h.className="kts-chip",h.type="button",h.textContent=f.label,h.disabled=C,h.addEventListener("mousedown",L=>L.preventDefault()),h.addEventListener("click",()=>s(f)),x.appendChild(h)}B()},s=t=>{if(u!=="available"){E.textContent=ie[t.id]??"",I(!1),B();return}r&&l(j(Y(r),t.instruction))},l=t=>{p=t,y=++w,E.textContent="",I(!0),M({type:"generate",id:y,instruction:t})};function v(t){var f;switch(t.type){case"availability":u=t.state,o.textContent=u==="available"?"on-device":"samples",O();return;case"presets":(f=t.presets)!=null&&f.length&&z(t.presets);return;case"chunk":t.id===y&&(E.textContent=t.text,D.disabled=!t.text.trim(),B());return;case"done":t.id===y&&(E.textContent=t.text,I(!1),B());return;case"error":t.id===y&&(A.textContent="Generation failed — try again.",I(!1));return;case"aborted":t.id===y&&I(!1);return}}k.addEventListener("input",()=>I(C)),k.addEventListener("keydown",t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),k.value.trim()&&r&&u==="available"&&l(j(Y(r),k.value.trim())))}),T.addEventListener("click",()=>{k.value.trim()&&r&&l(j(Y(r),k.value.trim()))}),W.addEventListener("click",()=>{p&&l(p)}),D.addEventListener("click",()=>{var h;const t=(h=E.textContent)==null?void 0:h.trim();if(!t||!r)return;if(!r.isConnected){A.textContent="That field is gone — reopen on a field that still exists.";return}const f=r;$(),b(f,t)}),a("close").addEventListener("click",()=>$()),a("hide").addEventListener("click",()=>{$(),window.dispatchEvent(new CustomEvent("__ktsAssistantHide"))}),c.addEventListener("mousedown",t=>{t.target!==k&&t.target!==E&&t.preventDefault()});const F=t=>{const f=i.host;t.target!==f&&$()},Z=t=>{t.key==="Escape"&&n&&(t.stopPropagation(),$())},q=()=>{const t=c.offsetWidth||G,f=c.offsetHeight||260;let h=Number.parseFloat(c.style.left)||0,L=Number.parseFloat(c.style.top)||0;h=Math.min(Math.max(8,h),Math.max(8,window.innerWidth-t-8)),L=Math.min(Math.max(8,L),Math.max(8,window.innerHeight-f-8)),c.style.left=`${Math.round(h)}px`,c.style.top=`${Math.round(L)}px`},B=()=>{n&&requestAnimationFrame(q)},we=t=>{const f=c.offsetHeight||260,h=t.right-G;let L=t.bottom+6;L+f>window.innerHeight-8&&(L=t.top-f-6),c.style.left=`${Math.round(h)}px`,c.style.top=`${Math.round(L)}px`,q()};let ee=0,te=0;const ne=t=>{const f=c.offsetWidth||G,h=c.offsetHeight||260,L=Math.min(Math.max(8,t.clientX-ee),Math.max(8,window.innerWidth-f-8)),ve=Math.min(Math.max(8,t.clientY-te),Math.max(8,window.innerHeight-h-8));c.style.left=`${Math.round(L)}px`,c.style.top=`${Math.round(ve)}px`},X=()=>{document.removeEventListener("pointermove",ne,!0),document.removeEventListener("pointerup",X,!0)};return c.querySelector(".kts-row").addEventListener("pointerdown",t=>{if(t.button!==0||t.target.closest('[data-el="close"]'))return;t.preventDefault();const h=c.getBoundingClientRect();ee=t.clientX-h.left,te=t.clientY-h.top,document.addEventListener("pointermove",ne,!0),document.addEventListener("pointerup",X,!0)}),{isOpen:()=>n,open(t,f){r=t,n=!0,E.textContent="",p="",k.value="",c.classList.add("kts-open"),we(f),g(!0),o.textContent="…",M({type:"availability"}),z(oe);const h={host:location.hostname,title:document.title};h.host&&M({type:"presets",id:++w,host:h.host,title:h.title}),document.addEventListener("pointerdown",F,!0),document.addEventListener("keydown",Z,!0),requestAnimationFrame(()=>k.focus())},close(){$()},destroy(){$(),d==null||d.disconnect(),d=null,c.remove(),m.remove()}};function $(){if(!n)return;n=!1,X(),y&&M({type:"abort",id:y}),c.classList.remove("kts-open"),document.removeEventListener("pointerdown",F,!0),document.removeEventListener("keydown",Z,!0),g(!1);const t=r;r=null,t!=null&&t.isConnected&&t.focus()}}function le(e){const i=window.__ktsSession;return i?(["stopped","completed","failed","idle"].includes(i.status.phase)||(i.stopped=!0,i.paused=!1,i.status.phase="stopping",i.status.message="Stopping typing"),{...i.status}):{sessionId:null,mode:null,phase:"idle",progress:0,currentFieldIndex:0,totalFields:0,completedFields:0,failedFields:0,message:""}}function de(e){const i=window,b=i.__ktsSession;if(b&&!["idle","stopped","completed","failed"].includes(b.status.phase))return{ok:!1,errorCode:"ACTIVE_SESSION",status:{...b.status,message:"A typing session is already active"}};const g=n=>n instanceof HTMLTextAreaElement?!n.disabled&&!n.readOnly:n instanceof HTMLInputElement?["text","email","search","url","tel",""].includes(n.type)&&!n.disabled&&!n.readOnly:n instanceof HTMLElement&&n.isContentEditable,m=e.mode==="basic"?[{element:document.activeElement,text:e.text??"",label:"Selected field"}]:(e.fields??[]).map(n=>{var r;return{element:((r=i.__ktsScan)==null?void 0:r.token)===n.scanToken?i.__ktsScan.elements.get(n.id)??null:document.querySelector(`[data-kts-scan-token="${CSS.escape(n.scanToken)}"][data-kts-field-id="${CSS.escape(n.id)}"]`),text:n.text,label:n.label}});if(m.length===0||m.some(n=>!n.text.trim()))return{ok:!1,errorCode:"EMPTY_TEXT",status:{sessionId:null,mode:e.mode,phase:"failed",progress:0,currentFieldIndex:0,totalFields:m.length,completedFields:0,failedFields:0,message:"Add text for at least one editable field"}};if(m.some(n=>!g(n.element)||!n.element.isConnected))return{ok:!1,errorCode:"INVALID_TARGET",status:{sessionId:null,mode:e.mode,phase:"failed",progress:0,currentFieldIndex:0,totalFields:m.length,completedFields:0,failedFields:0,message:e.mode==="basic"?"Focus an editable text field on the page and try again":"The page changed since the last scan. Rescan the page — your field text is kept."}};const a={sessionId:typeof crypto.randomUUID=="function"?crypto.randomUUID():`session-${Date.now()}-${Math.random().toString(36).slice(2)}`,mode:e.mode,phase:"validating",progress:0,currentFieldIndex:0,totalFields:m.length,completedFields:0,failedFields:0,message:"Preparing typing session"},o={status:a,paused:!1,stopped:!1,audioContext:null};i.__ktsSession=o;const x=(n,r,u,d)=>{var y,p;const w=new InputEvent("beforeinput",{bubbles:!0,cancelable:!0,data:d,inputType:u});if(!n.dispatchEvent(w))return!1;if(n instanceof HTMLInputElement){const C=(y=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:y.set;C==null||C.call(n,r)}else if(n instanceof HTMLTextAreaElement){const C=(p=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value"))==null?void 0:p.set;C==null||C.call(n,r)}else n.textContent=r;return n.dispatchEvent(new InputEvent("input",{bubbles:!0,data:d,inputType:u})),!0},k=n=>n instanceof HTMLInputElement||n instanceof HTMLTextAreaElement?n.value:n.textContent??"",T=async n=>{let r=Math.max(0,n);for(;r>0;){if(o.stopped)throw new Error("SESSION_STOPPED");if(o.paused){await new Promise(d=>window.setTimeout(d,50));continue}const u=Math.min(r,50);await new Promise(d=>window.setTimeout(d,u)),r-=u}},E=()=>{const n=Math.max(10,e.typingConfig.delay);return e.typingConfig.typingStyle==="random"?n*(.5+Math.random()*2):n},A=()=>{if(!e.typingConfig.soundEnabled||!o.audioContext)return;const n=o.audioContext.createOscillator(),r=o.audioContext.createGain();n.connect(r),r.connect(o.audioContext.destination),n.frequency.value=760+Math.random()*160,n.type="square",r.gain.setValueAtTime(.035,o.audioContext.currentTime),r.gain.exponentialRampToValueAtTime(.001,o.audioContext.currentTime+.06),n.start(),n.stop(o.audioContext.currentTime+.06)},D=()=>{var r,u;if(e.mode!=="advanced")return;const n=new Set((e.fields??[]).map(d=>d.scanToken));for(const d of n){for(const w of document.querySelectorAll(`[data-kts-scan-token="${CSS.escape(d)}"]`))w.removeAttribute("data-kts-scan-token"),w.removeAttribute("data-kts-field-id");(r=document.getElementById(`kts-scan-style-${d}`))==null||r.remove(),((u=i.__ktsScan)==null?void 0:u.token)===d&&i.__ktsScan.cleanupTimer&&(clearTimeout(i.__ktsScan.cleanupTimer),i.__ktsScan.cleanupTimer=void 0)}};return(async()=>{var u,d;const n=Math.max(1,m.reduce((w,y)=>w+y.text.length,0));let r=0;try{if(e.typingConfig.soundEnabled)try{o.audioContext=new AudioContext}catch{o.audioContext=null}const w=((u=e.advancedConfig)==null?void 0:u.initialDelay)??0;w>0&&(a.phase="delaying",a.message=`Starting in ${w} seconds`,await T(w*1e3));for(let y=0;y<m.length;y+=1){if(o.stopped)throw new Error("SESSION_STOPPED");const p=m[y];if(!g(p.element)||!p.element.isConnected){a.failedFields+=1;continue}if(a.phase="running",a.currentFieldIndex=y,a.message=`Typing into ${p.label}`,p.element.scrollIntoView({block:"center"}),p.element.focus(),!x(p.element,"","deleteContentBackward",null)){a.failedFields+=1;continue}const C=e.typingConfig.typingStyle==="word-by-word"?p.text.match(/\S+\s*/g)??[]:Array.from(p.text);for(const M of C){if(o.stopped)throw new Error("SESSION_STOPPED");for(;o.paused;)await T(50);const I=k(p.element);if(e.typingConfig.includeMistakes&&M.length===1&&r>0&&Math.random()<.03){const O="qwertyuiopasdfghjklzxcvbnm"[Math.floor(Math.random()*26)];x(p.element,I+O,"insertText",O),A(),await T(E()*1.5),x(p.element,I,"deleteContentBackward",null),await T(E())}if(!x(p.element,k(p.element)+M,"insertText",M))throw new Error("INPUT_REJECTED");A(),r+=M.length,a.progress=Math.min(100,r/n*100),await T(e.typingConfig.typingStyle==="word-by-word"?E()*3:E())}p.element.dispatchEvent(new Event("change",{bubbles:!0})),a.completedFields+=1;const P=((d=e.advancedConfig)==null?void 0:d.interFieldDelay)??0;y<m.length-1&&P>0&&(a.phase="delaying",a.message="Waiting for the next field",await T(P*1e3))}a.progress=100,a.phase=a.failedFields>0?"failed":"completed",a.message=a.failedFields>0?`Completed ${a.completedFields} fields; ${a.failedFields} failed`:"Typing completed"}catch(w){w instanceof Error&&w.message==="SESSION_STOPPED"?(a.phase="stopped",a.message="Typing stopped"):(a.phase="failed",a.message="Typing failed before completion")}finally{D(),o.audioContext&&(o.audioContext.close(),o.audioContext=null)}})(),{ok:!0,status:{...a}}}const S={version:4,typing:{delay:50,includeMistakes:!1,soundEnabled:!1,typingStyle:"normal"},advanced:{initialDelay:2,hideExtension:!1,interFieldDelay:1},theme:"system",ui:{activeTab:"basic",moreOptionsExpanded:!0,timingExpanded:!1},shortcut:{persistScript:!1},assistant:{enabled:!0}},R=e=>typeof e=="object"&&e!==null,U=(e,i,b,g)=>typeof e=="number"&&Number.isFinite(e)?Math.min(b,Math.max(i,e)):g,H=(e,i)=>typeof e=="boolean"?e:i,ce=e=>{if(!R(e))return S;const i=R(e.typing)?e.typing:{},b=R(e.advanced)?e.advanced:{},g=R(e.ui)?e.ui:{},m=R(e.shortcut)?e.shortcut:{},c=R(e.assistant)?e.assistant:{},a=["normal","random","word-by-word"],o=["light","dark","system"],x=["basic","advanced"];return{version:4,typing:{delay:U(i.delay,10,300,S.typing.delay),includeMistakes:H(i.includeMistakes,S.typing.includeMistakes),soundEnabled:H(i.soundEnabled,S.typing.soundEnabled),typingStyle:a.includes(i.typingStyle)?i.typingStyle:S.typing.typingStyle},advanced:{initialDelay:U(b.initialDelay,0,10,S.advanced.initialDelay),hideExtension:H(b.hideExtension,S.advanced.hideExtension),interFieldDelay:U(b.interFieldDelay,0,5,S.advanced.interFieldDelay)},theme:o.includes(e.theme)?e.theme:S.theme,ui:{activeTab:x.includes(g.activeTab)?g.activeTab:S.ui.activeTab,moreOptionsExpanded:H(g.moreOptionsExpanded,S.ui.moreOptionsExpanded),timingExpanded:H(g.timingExpanded,S.ui.timingExpanded)},shortcut:{persistScript:H(m.persistScript,S.shortcut.persistScript)},assistant:{enabled:H(c.enabled,S.assistant.enabled)}}},K="preferences",pe=async()=>{try{const e=await chrome.storage.local.get(K);return ce(e[K])}catch{return S}},J="__kts_assistant_host",_=22,N=4,ue=120,fe=24,he=300,me=350,ge=["validating","delaying","running","paused","stopping"],Q=`
  <svg viewBox="0 0 22 22" width="14" height="14" aria-hidden="true">
    <rect x="13" y="4" width="3" height="14" rx="1.5" fill="#ffffff"/>
    <rect x="8" y="6" width="2.4" height="10" rx="1.2" fill="#ffffff" opacity="0.55"/>
    <rect x="3.6" y="8" width="2.4" height="6" rx="1.2" fill="#ffffff" opacity="0.3"/>
  </svg>`,ye=`
  <svg viewBox="0 0 22 22" width="12" height="12" aria-hidden="true">
    <rect x="5" y="5" width="12" height="12" rx="2" fill="#ffffff"/>
  </svg>`;function be(){var z;const e=window,i=[],b=(s,l,v,F)=>{s.addEventListener(l,v,F),i.push(()=>s.removeEventListener(l,v,F))};(z=document.getElementById(J))==null||z.remove();const g=document.createElement("div");g.id=J;const m=g.attachShadow({mode:"closed"}),c=document.createElement("style");c.textContent=`
    :host { all: initial; }
    .kts-icon {
      position: fixed;
      width: ${_}px;
      height: ${_}px;
      display: flex;
      align-items: center;
      justify-content: center;
      border: none;
      border-radius: 6px;
      background: #5b5bd6;
      box-shadow: 0 1px 4px rgba(0, 0, 0, 0.25);
      cursor: pointer;
      padding: 0;
      z-index: 2147483646;
      opacity: 0;
      transform: scale(0.85);
      pointer-events: none;
      transition: opacity 0.12s ease, transform 0.12s ease;
    }
    .kts-icon.kts-visible {
      opacity: 0.6;
      transform: scale(1);
      pointer-events: auto;
    }
    .kts-icon.kts-visible:hover,
    .kts-icon.kts-visible:focus-visible { opacity: 1; }
    .kts-icon.kts-stop { background: #dc2626; opacity: 0.95; }
    .kts-icon.kts-pulse { animation: kts-pulse 0.35s ease; }
    @keyframes kts-pulse {
      50% { transform: scale(1.18); }
    }
    .kts-status {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 2147483646;
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 14px;
      border-radius: 10px;
      background: #1e1e2e;
      color: #fff;
      font: 12px/1.4 system-ui, sans-serif;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.25);
      pointer-events: none;
      opacity: 0;
      transform: translateY(4px);
      transition: opacity 0.15s ease, transform 0.15s ease;
    }
    .kts-status.kts-visible { opacity: 1; transform: translateY(0); }
    .kts-caret {
      width: 3px;
      height: 14px;
      border-radius: 2px;
      background: #5b5bd6;
      animation: kts-blink 1.06s steps(1) infinite;
    }
    @keyframes kts-blink { 50% { opacity: 0; } }
    @media (prefers-reduced-motion: reduce) {
      .kts-icon, .kts-status { transition: none; }
      .kts-icon.kts-pulse { animation: none; }
    }
  `,m.appendChild(c),document.documentElement.appendChild(g),i.push(()=>g.remove());const a=s=>{const l=document.createElement("div");l.className="kts-status";const v=document.createElement("span");v.className="kts-caret";const F=document.createElement("span");F.textContent=s,l.append(v,F),m.appendChild(l),requestAnimationFrame(()=>l.classList.add("kts-visible")),window.setTimeout(()=>{l.classList.remove("kts-visible"),window.setTimeout(()=>l.remove(),200)},2200)},o=document.createElement("button");o.type="button",o.className="kts-icon",o.innerHTML=Q,o.title="Generate with TypeReel (AI runs on your device) · Alt+Shift+A to hide",m.appendChild(o);let x=null,k=null,T=!1,E=null,A=!1,D=!1;const n=re({shadow:m,typeIntoField:(s,l)=>{s.focus(),pe().then(v=>{de({mode:"basic",text:l,typingConfig:v.typing})}).catch(()=>{})},onOpenChange:s=>{D=s,s&&C()}});i.push(()=>n.destroy());const r=s=>{if(!(s instanceof HTMLElement))return!1;let l=!1;if(s instanceof HTMLTextAreaElement?l=!s.disabled&&!s.readOnly:s instanceof HTMLInputElement?l=["text","email","search","url","tel",""].includes(s.type)&&!s.disabled&&!s.readOnly:l=s.isContentEditable,!l)return!1;const v=s.getBoundingClientRect();return v.width>=ue&&v.height>=fe},u=()=>{if(!x)return;if(!x.isConnected){M();return}const s=x.getBoundingClientRect();if(s.width===0&&s.height===0){M();return}let l,v;s.height>80?(l=s.right-_-6,v=s.bottom-_-6):(l=s.right-_,v=s.top-_-N,v<N&&(v=s.top+(s.height-_)/2,l=s.right-_-6)),l=Math.min(Math.max(N,l),window.innerWidth-_-N),v=Math.min(Math.max(N,v),window.innerHeight-_-N),o.style.left=`${Math.round(l)}px`,o.style.top=`${Math.round(v)}px`},d=()=>{T||!x||(T=!0,requestAnimationFrame(()=>{T=!1,u()}))},w=s=>{A!==s&&(A=s,o.classList.toggle("kts-stop",s),o.innerHTML=s?ye:Q,o.title=s?"Stop TypeReel typing":"Generate with TypeReel (AI runs on your device) · Alt+Shift+A to hide")},y=()=>{E===null&&(E=window.setInterval(()=>{var l;const s=((l=e.__ktsSession)==null?void 0:l.status.phase)??"idle";w(ge.includes(s)),u()},me))},p=()=>{E!==null&&(clearInterval(E),E=null)};i.push(p);const C=()=>{k!==null&&(clearTimeout(k),k=null)},P=s=>{C(),x=s,u(),o.classList.add("kts-visible"),y()},M=()=>{D||(C(),x=null,o.classList.remove("kts-visible"),w(!1),p())};i.push(()=>{D=!1,M()});const I=()=>{D||(C(),k=window.setTimeout(()=>{k=null,M()},he))};b(document,"focusin",s=>{const l=s.target;if(l===g){C();return}r(l)?P(l):x&&I()},{passive:!0}),b(document,"focusout",()=>{x&&I()},{passive:!0}),b(document,"scroll",d,{capture:!0,passive:!0}),b(window,"resize",d,{passive:!0}),o.addEventListener("mousedown",s=>s.preventDefault()),o.addEventListener("click",()=>{if(A){le(),w(!1);return}if(x){if(n.isOpen()){n.close();return}o.classList.remove("kts-pulse"),o.offsetWidth,o.classList.add("kts-pulse"),n.open(x,o.getBoundingClientRect())}}),b(window,"__ktsAssistantHide",()=>{var s;(s=window.__ktsAssistant)==null||s.unmount()});const O=r(document.activeElement);return O&&P(document.activeElement),a(O?"TypeReel is on — tap the ✨ icon to generate. Alt+Shift+A hides it.":"TypeReel is on — click any text field to generate. Alt+Shift+A hides it."),{mounted:!0,unmount(){for(const s of i.splice(0))try{s()}catch{}window.__ktsAssistant=void 0}}}const xe=se(()=>{const e=window,i=e.__ktsAssistant;if(i!=null&&i.mounted){i.unmount();return}e.__ktsAssistant=be()});function Ee(){}function V(e,...i){}const ke={debug:(...e)=>V(console.debug,...e),log:(...e)=>V(console.log,...e),warn:(...e)=>V(console.warn,...e),error:(...e)=>V(console.error,...e)};return(async()=>{try{return await xe.main()}catch(e){throw ke.error('The unlisted script "assistant" crashed on startup!',e),e}})()}();
assistant;
